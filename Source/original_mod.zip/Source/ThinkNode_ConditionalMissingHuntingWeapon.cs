﻿using RimWorld;
using Verse;
using Verse.AI;

namespace FindAGunDamnIt
{
    public class ThinkNode_ConditionalMissingHuntingWeapon : ThinkNode_Conditional
    {
        protected override bool Satisfied(Pawn pawn)
        {
            return !WorkGiver_HunterHunt.HasHuntingWeapon(pawn);
        }
    }
}