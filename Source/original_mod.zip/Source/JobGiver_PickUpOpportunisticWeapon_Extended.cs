﻿using System;
using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace FindAGunDamnIt
{
    public class JobGiver_PickUpOpportunisticWeapon_Extended : JobGiver_PickUpOpportunisticWeapon
    {

        protected override Job TryGiveJob(Pawn pawn)
        {
            return TryOutfit(pawn);
        }

        private Job TryOutfit(Pawn pawn)
        {
            if (pawn?.equipment == null)
            {
                return null;
            }

            if (pawn?.story?.WorkTagIsDisabled(WorkTags.Violent) ?? false)
            {
                Gunfitter.Trace(pawn + " is a wuss and cant even gunfit.");
                return null;
            }

            if (!pawn?.health?.capacities?.CapableOf(PawnCapacityDefOf.Manipulation) ?? false)
            {
                Gunfitter.Trace(pawn + " is cant even gunfit, no hands danceeee.");
                return null;
            }

            List<Thing> list = pawn?.Map?.listerThings?.ThingsInGroup(ThingRequestGroup.Weapon);
            Outfit currentOutfit = pawn?.outfits?.CurrentOutfit;
            if (currentOutfit == null || list == null)
            {
                return null;
            }

            if (FindAGoodThing(pawn, list, out var job)) return job;

            Gunfitter.Trace("Nothing for [" + pawn + "]");

            return null;
        }

        private bool FindAGoodThing(Pawn pawn, List<Thing> list, out Job job)
        {
            Thing thing = null;

            List<Thing> things = new List<Thing>();
            foreach (var gun in list)
            {
                if (!this.ShouldEquipByOutfit(gun, pawn)
                    || !pawn.CanReserveAndReach(gun, PathEndMode.OnCell, pawn.NormalMaxDanger(), 1, -1, null, false)
                ) continue;

                things.Add(gun);
                thing = gun;
                Gunfitter.Trace(thing + " - can be gunfitted");
            }

            if (thing != null)
            {
                if (PickWhatIWank(pawn, out job, things)) return true;
            }

            job = null;
            return false;
        }

        private static bool PickWhatIWank(Pawn pawn, out Job job, List<Thing> things)
        {
            Thing want = ThingIWant(things);
            if (want != null)
            {
                Gunfitter.Trace("[" + want + "] for [" + pawn + "]");
                {
                    job = new Job(JobDefOf.Equip, want);
                    return true;
                }
            }
            else
            {
                Log.ErrorOnce("That's odd wanted a thing but then forgot about it, What mods are you using?", 1000);
            }


            job = null;
            return false;
        }

        private static Thing ThingIWant(List<Thing> things)
        {
            return things?.RandomElementByWeight(x=>Math.Max(x.MarketValue, 1f) * 
                   Math.Max(x.GetStatValue(StatDefOf.MeleeWeapon_AverageDPS),1f)
            );
        }
    }
}