using System.Reflection;
using Harmony;
using RimWorld;
using Verse;

namespace FindAGunDamnIt
{
    [StaticConstructorOnStartup]
    public static class Constants
    {
        public static FieldInfo MinMeleeWeaponDPSThreshold = AccessTools.Field(typeof(JobGiver_PickUpOpportunisticWeapon), "MinMeleeWeaponDPSThreshold");
        public static MethodInfo ShouldEquip = AccessTools.Method(typeof(JobGiver_PickUpOpportunisticWeapon), "ShouldEquip", new []{typeof(Thing), typeof(Pawn)});
        
        static Constants()
        {
        }

        public static bool Brawler(Pawn pawn)
        {
            return pawn.story.traits.HasTrait(TraitDefOf.Brawler);
        }
    }
}