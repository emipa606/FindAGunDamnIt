//#define DEBUG
//comment that out^

using System;
using RimWorld;
using Verse;


namespace FindAGunDamnIt
{
    public static class Gunfitter
    {
        
        public static void Trace(string wtf)
        {
            #if DEBUG
            Log.Message("FindAGunDamnIt::"+wtf);
            #endif
        }
        
        public static bool ShouldEquipByOutfit(this JobGiver_PickUpOpportunisticWeapon that, Thing thing, Pawn pawn)
        {
            if (thing.IsForbidden(pawn))
            {
                Trace("Verboten, sorry!");
                return false;
            }
            Outfit currentOutfit = pawn.outfits.CurrentOutfit;

            if (currentOutfit!=null && !currentOutfit.filter.Allows(thing))
            {
                Trace("Not Allowed To Thing : " + thing);
                return false;
            }

            return that.isBetterThanCurrent(thing, pawn);
        }

        

        private static bool isBetterThanCurrent(this JobGiver_PickUpOpportunisticWeapon that, Thing thing, Pawn pawn)
        {
            if (thing == null || pawn == null) return false;
            
            var thingEq = thing.TryGetComp<CompEquippable>();
            if (thingEq == null) return false;
            
            var verb = thingEq.PrimaryVerb;

            var hurts = verb.HarmsHealth();
            var boom = verb.UsesExplosiveProjectiles();

            var primaryEqPrimaryVerb = pawn?.equipment?.PrimaryEq?.PrimaryVerb;
            var pawnBoom = primaryEqPrimaryVerb?.UsesExplosiveProjectiles() ?? false;


            var amHunter = ThinkNode_ConditionalHunter.AmHunter(pawn);

            //am hunter, dont want booms
            if (amHunter && boom) return false;
            
            //pawn has Explosive but is hunter, get rid of
            if (!boom && amHunter && pawnBoom) return true;
            
            

            try
            {
                var should = Constants.ShouldEquip.Invoke(that, new object[] {thing, pawn});
                Trace("Classic Method said  : "+should);
                if (should != null && ! (bool) should){ return false;}
            } 
            catch (Exception e)
            {
                Trace("Had a mishap with default should equip" + e);
            }

            if (!hurts)
            {
                Trace("It doesn't even hurt!");
                return false;
            }
            
            
            var ranged = pawn?.equipment?.Primary?.def?.IsRangedWeapon ?? false;
            var brawler = Constants.Brawler(pawn);
            if (thing.def.IsRangedWeapon)
            {
                if (brawler)
                {
                    Trace("Brawler doesn't want your gun.");
                    return false;
                }

                if (!ranged && amHunter)
                {
                    Trace("Ranged Weapon is better for hunter!");
                    return true;
                }
            }else if (brawler && ranged)
            {
                Trace("Brawler hates this gun we gave them.");
                return true;
            }
                
            if (thing.MarketValue > Math.Min(pawn?.equipment?.Primary?.MarketValue??0f, 5f))
            {
                return true;
            }

            Trace(thing+"is garbage.");                    
            return false;
        }
    }
}